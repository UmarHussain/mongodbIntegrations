package mongodbsbjr;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import net.sf.dynamicreports.jasper.builder.JasperReportBuilder;
import net.sf.dynamicreports.report.builder.DynamicReports;
import net.sf.dynamicreports.report.builder.column.Columns;
import net.sf.dynamicreports.report.builder.component.Components;
import net.sf.dynamicreports.report.builder.datatype.DataTypes;
import net.sf.dynamicreports.report.constant.HorizontalAlignment;
import net.sf.dynamicreports.report.datasource.DRDataSource;
import net.sf.dynamicreports.report.exception.DRException;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;



@SpringBootApplication
public class Application implements CommandLineRunner {

	@Autowired
	private CustomerRepository repository;

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		repository.deleteAll();

		// save a couple of customers names
		repository.save(new Customer("Rama", "Rama"));
		repository.save(new Customer("Alice", "Smith"));
		repository.save(new Customer("Bisma", "BobSmith"));
		repository.save(new Customer("Mallanna", "Mallanna"));
		// fetch all customers
		System.out.println("Customers found with findAll():");
		System.out.println("-------------------------------");
		for (Customer customer : repository.findAll()) {
			System.out.println(customer);
		}
		System.out.println();

		// fetch an individual customer
		System.out.println("Customer found with findByFirstName('Alice'):");
		System.out.println("--------------------------------");
		System.out.println(repository.findByFirstName("Alice"));

		System.out.println("Customers found with findByLastName('Smith'):");
		System.out.println("--------------------------------");
		for (Customer customer : repository.findByLastName("Smith")) {
			System.out.println(customer);
		}
		generateReport();
		generateDynamicReport();
	}	


	public void generateReport() throws JRException {
		JasperReport jasperReport;
		JasperPrint jasperPrint;
		jasperReport = JasperCompileManager
				.compileReport("src/main/resources/static/jasper/customer_report.jrxml");	
		List<Customer> custList = new ArrayList<Customer>();
		for (Customer customer : repository.findAll()) {			
			custList.add(customer);
		}
		CustomJRDataSource<Customer> dataSource = new CustomJRDataSource<Customer>().initBy(custList);
		jasperPrint = JasperFillManager.fillReport(jasperReport, new HashMap(),
				dataSource);	
		JasperExportManager.exportReportToPdfFile(jasperPrint,
				"src/reports/customer_report.pdf");
	}

	
	private void generateDynamicReport(){
		
		JasperReportBuilder report = DynamicReports.report();//a new report
		report
		  .columns(
		  	Columns.column("id", "id", DataTypes.stringType())
		  		.setHorizontalAlignment(HorizontalAlignment.LEFT),
		  	Columns.column("firstName", "firstName", DataTypes.stringType()),
		  	Columns.column("firstName", "lastName", DataTypes.stringType())
		  		.setHorizontalAlignment(HorizontalAlignment.LEFT)
		  	)
		  .title(//title of the report
		  	Components.text("Customer Report")
		  		.setHorizontalAlignment(HorizontalAlignment.CENTER))
		  .pageFooter(Components.pageXofY())//show page number on the page footer
		  .setDataSource(getCollections());
		
		try {
			//report.show();//show the report
			report.toPdf(new FileOutputStream("src/reports/dynamic-pdf.pdf"));//export the report to a pdf file
			report.toXlsx(new FileOutputStream("src/reports/dynamic-xsl.xlsx"));
			report.toDocx(new FileOutputStream("src/reports/dynamic-docs.docx"));
		} catch (DRException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
		
	private JRDataSource createDataSource() {

		DRDataSource dataSource = new DRDataSource("Id");
		for (Customer customer : repository.findAll()) {
			
			dataSource.add(customer.getId());
			//dataSource.add(customer.getFirstName());
			//dataSource.add(customer.getLastName());
			
		}
		return dataSource;

	}
	
	
	private Collection<Customer> getCollections(){

        Collection<Customer> list = new ArrayList<>();
        for (Customer customer : repository.findAll()) {
        	list.add(customer);	        
        }
        return list;
	}
	private JRDataSource createDataSource1() {

		DRDataSource dataSource = new DRDataSource("firstName");
		for (Customer customer : repository.findAll()) {
			
			//dataSource.add(customer.getId());
			dataSource.add(customer.getFirstName());
			//dataSource.add(customer.getLastName());
			
		}
		return dataSource;

	}

}
